from tkinter import *
from PIL import Image, ImageTk
import mysql.connector
from tkinter import messagebox

# ---------------variables------------------------------------------------------------




def add_data():


   # print(e1,e2,e3,e4)

    conn = mysql.connector.connect(host="localhost", username="root", password="bhumika@12", database="testdb")
    mycursor = conn.cursor()
    sql = "INSERT INTO customer (mobilenumber,name,email,gender,totalorder,amountpaid) VALUES (%s, %s,%s,%s,%s,%s)"
    val=(e1,e2,e3,e4,e5,e6)
    mycursor.execute(sql, val)

    conn.commit()
   # messagebox.showinfo("success", "data added succesfully")

    #mycursor.close()

    #conn.close()


    #except:
       # conn.close()
       # messagebox.showinfo("invalid data","fill all data")

    #if mob_var.get()=="" or mail_var.get()=="":
       # messagebox.showinfo("error","please fill all details",parent=winn)














def cost_butt():
    t1=Toplevel(winn)
    t1.geometry('1020x390+250+272')
    t1.title('COSTUMER DETAILS')
    t1.resizable(0,0)


    l1 = Label(t1, text='PLEASE FILL THE FORM DETAILS', fg='gold', bg='black',
               font=('Franklin Gothic Heavy', 28))
    l1.place(x=0, y=0, width=1220, height=30)

    lab_fra=LabelFrame(t1,text='ℂ𝕆𝕊𝕋𝕌𝕄𝔼ℝ 𝔻𝔼𝕋𝔸𝕀𝕃𝕊 ',bd=3,relief=RIDGE,font=('Algerian',13))
    lab_fra.place(x=5,y=32,width=425,height=360)

    l2=Label(lab_fra,text='MOBILE NO',fg='#5d8581',font=('Algerian',13))
    l2.grid(row=0,column=0)

    mob_var = IntVar()
    e1=Entry(lab_fra,textvariable=mob_var,bg='#7a6ee6',bd=2,fg='#850b27',font=('Algerian',13),width=20)
    e1.grid(row=0,column=1,padx=5)

    l3=Label(lab_fra,text='NAME',fg='#5d8581',font=('Algerian',13))
    l3.grid(row=1,column=0,pady=2)

    name_var = StringVar()

    e2=Entry(lab_fra,textvariable=name_var,bg='#7a6ee6',bd=2,fg='#850b27',font=('Algerian',13),width=20)
    e2.grid(row=1,column=1,padx=5,pady=2)

    l4=Label(lab_fra,text='EMAIL',fg='#5d8581',font=('Algerian',13))
    l4.grid(row=2,column=0,pady=2)

    mail_var = StringVar()

    e3=Entry(lab_fra,textvariable=mail_var,bg='#7a6ee6',bd=2,fg='#850b27',font=('Algerian',13),width=20)
    e3.grid(row=2,column=1,padx=5,pady=2)

    l5=Label(lab_fra,text='GENDER',fg='#5d8581',font=('Algerian',13))
    l5.grid(row=3,column=0,pady=2)

    gender_var = StringVar()

    e4=Entry(lab_fra,textvariable=gender_var,bg='#7a6ee6',bd=2,fg='#850b27',font=('Algerian',13),width=20)
    e4.grid(row=3,column=1,padx=5,pady=2)

    l6=Label(lab_fra,text='TOTAL ORDER',fg='#5d8581',font=('Algerian',13))
    l6.grid(row=4,column=0,pady=2)

    total_var = StringVar()

    e5=Entry(lab_fra,textvariable=total_var,bg='#7a6ee6',bd=2,fg='#850b27',font=('Algerian',13),width=20)
    e5.grid(row=4,column=1,padx=5,pady=2)

    l7=Label(lab_fra,text='AMOUNT PAID',fg='#5d8581',font=('Algerian',13))
    l7.grid(row=5,column=0,pady=2)

    paid_var = StringVar()
    e6=Entry(lab_fra,textvariable=paid_var,bg='#7a6ee6',bd=2,fg='#850b27',font=('Algerian',13),width=20)
    e6.grid(row=5,column=1,padx=5,pady=2)

    lab_fra1=Frame(lab_fra,bd=4,relief=RIDGE)
    lab_fra1.place(x=5,y=250,width=410,height=50)

    b1=Button(lab_fra1,text='ADD',width=8,bg='#bb8bd6',command=add_data,fg='#91202d',font=('Algerian',13))
    b1.grid(row=0,column=0,padx=4,pady=5)

    b2=Button(lab_fra1,text='UPDATE',width=8,bg='#bb8bd6',fg='#91202d',font=('Algerian',13))
    b2.grid(row=0,column=1,padx=4,pady=5)

    b3=Button(lab_fra1,text='DELETE',width=8,bg='#bb8bd6',fg='#91202d',font=('Algerian',13))
    b3.grid(row=0,column=2,padx=4,pady=5)

    b4=Button(lab_fra1,text='RESET',width=8,bg='#bb8bd6',fg='#91202d',font=('Algerian',13))
    b4.grid(row=0,column=3,padx=4,pady=5)

    lab_fra2=LabelFrame(t1,text='𝓥𝓘𝓔𝓦 𝓓𝓔𝓣𝓐𝓘𝓛',bd=3,relief=RIDGE,font=('Algerian',13))
    lab_fra2.place(x=430,y=32,width=585,height=360)

    l8=Label(lab_fra2,text='SEARCH BY',bg='red',fg='yellow',font=('Algerian',13))
    l8.grid(row=0,column=0,pady=2)

    a7=StringVar()

    e7=Entry(lab_fra2,textvariable=a7,bg='#aeebfc',bd=2,fg='#2b00ff',font=('Algerian',13),width=20)
    e7.grid(row=0,column=1,padx=5,pady=2)

    b5=Button(lab_fra2,text='SEARCH',width=8,bg='#cfba5d',fg='#961002',font=('Algerian',13))
    b5.grid(row=0,column=2,padx=4,pady=5)

    b6=Button(lab_fra2,text='SHOW ALL DATA',width=14,bg='#cfba5d',fg='#961002',font=('Algerian',13))
    b6.grid(row=0,column=3,padx=4,pady=5)

    lab_fra3=Frame(lab_fra2,bd=4,relief=RIDGE)
    lab_fra3.place(x=5,y=40,width=570,height=280)


    t1.mainloop()







def menu():  # designing of the menu tab----------------------------->
    t2 = Toplevel(winn)
    t2.geometry('1920x1024')
    t2.title('MENU CARD')

    img_1 = Image.open('D:\\python\\hotel management\\images\\menu-1.jpg')
    img_1 = img_1.resize((430,700), Image.Resampling.LANCZOS)
    img1 = ImageTk.PhotoImage(img_1)

    l1 = Label(t2, image=img1,padx=15)
    l1.grid(row=0,column=0)

    img_2 = Image.open('D:\\python\\hotel management\\images\\menu-2.jpg')
    img_2 = img_2.resize((430, 700), Image.Resampling.LANCZOS)
    img2 = ImageTk.PhotoImage(img_2)

    l2 = Label(t2, image=img2,padx=15)
    l2.grid(row=0,column=1)

    img_3 = Image.open('D:\\python\\hotel management\\images\\menu-3.jpg')
    img_3 = img_3.resize((430, 700), Image.Resampling.LANCZOS)
    img3 = ImageTk.PhotoImage(img_3)

    l3 = Label(t2, image=img3, padx=15)
    l3.grid(row=0, column=2)

    t2.mainloop()

#--------------------------------------------------------------------------------------------------------------#
def bill():
    t3 = Toplevel(winn)
    t3.geometry('1270x690+0+0')
    t3.title('BILL GENERATION')
    t3.config(bg='firebrick4')
    topFrame=Frame(t3,bd=10,relief=RIDGE)
    topFrame.pack(side=TOP)
    labelTitle=Label(topFrame,text='Billing Management System',font=('arial',30,'bold'),bd=9,width=58)
    labelTitle.grid(row=0,column=0)

    #frame designing-------------------------------------------------------------------->>>>>>>>>>>>>>>>>>
    menuframe=Frame(t3,bd=10,relief=RIDGE)
    menuframe.pack(side=LEFT)

    def f1reset():
        e1.delete(0,END)
        e2.delete(0, END)
        e3.delete(0, END)
        e4.delete(0, END)
        e5.delete(0, END)
        e6.delete(0, END)
        e7.delete(0, END)
        e8.delete(0, END)
        e9.delete(0, END)

    def f1total():

        try: t1 = int(a1.get())
        except: t1=0

        try: t2 = int(a2.get())
        except: t2=0

        try: t3 = int(a3.get())
        except: t3=0

        try: t4 = int(a4.get())
        except: t4=0

        try: t5 = int(a5.get())
        except: t5=0

        try: t6 = int(a6.get())
        except: t6=0

        try: t7 = int(a7.get())
        except: t7=0

        try: t8 = int(a8.get())
        except: t8=0

        try: t9 = int(a9.get())
        except: t9=0

        #define cost

        c1=200*t1
        c2=140*t2
        c3=100*t3
        c4=220*t4
        c5=10*t5
        c6=20*t6
        c7=40*t7
        c8=20*t8
        c9=30*t9

        total=Label(f2,text='TOTAL',width=15,bg='green',bd=10,font=('Algerian',28))
        total.place(x=20,y=60)

        total=StringVar()

        p1 = Entry(f2, textvariable=total, bg='#aeebfc', bd=5, fg='#2b00ff', font=('Algerian', 20), relief=RIDGE, width=15)
        p1.place(x=80, y=130)

        totalcost=c1+c2+c3+c4+c5+c6+c7+c8+c9
        str_bill='Rs.',str(totalcost)
        total.set(str_bill)



    #first feame

    f=Frame(t3,bg='light yellow',bd=10,width=400,height=550,relief=RIDGE)
    f.place(x=10,y=100)

    l1=Label(f,text='Menu',fg='black',font=('Algerian',30))
    l1.place(x=100,y=20)

    l2=Label(f,text='Cheese Pizza......Rs.200',fg='black',font=('Algerian',20))
    l2.place(x=10,y=80)

    l3=Label(f,text='Masala Dosa......Rs.140',fg='black',font=('Algerian',20))
    l3.place(x=10,y=120)

    l4=Label(f,text='Idli Vada......Rs.100',fg='black',font=('Algerian',20))
    l4.place(x=10,y=160)

    l5=Label(f,text='Hakka Noodles......Rs.220',fg='black',font=('Algerian',20))
    l5.place(x=10,y=200)

    l6=Label(f,text='Tea......Rs.10',fg='black',font=('Algerian',20))
    l6.place(x=10,y=240)

    l7=Label(f,text='Coffee......Rs.20',fg='black',font=('Algerian',20))
    l7.place(x=10,y=280)

    l8=Label(f,text='Juice......Rs.40',fg='black',font=('Algerian',20))
    l8.place(x=10,y=320)

    l9=Label(f,text='Pancakes......Rs.20',fg='black',font=('Algerian',20))
    l9.place(x=10,y=360)

    l10=Label(f,text='omelette......Rs.30',fg='black',font=('Algerian',20))
    l10.place(x=10,y=400)

    #second frame

    f1=Frame(t3,bg='gold',bd=10,width=420,height=550,relief=RIDGE)
    f1.place(x=420,y=100)

    l1=Label(f1,text='Cheese Pizza',bg='red',fg='yellow',font=('Algerian',18))
    l1.place(x=5,y=8)

    a1=StringVar()

    e1=Entry(f1,textvariable=a1,bg='#aeebfc',bd=5,fg='#2b00ff',font=('Algerian',18),relief=RIDGE,width=5)
    e1.place(x=270,y=8)

    l2=Label(f1,text='Masala Dosa',bg='red',fg='yellow',font=('Algerian',18))
    l2.place(x=5,y=50)

    a2=StringVar()

    e2=Entry(f1,textvariable=a2,bg='#aeebfc',bd=5,fg='#2b00ff',font=('Algerian',18),relief=RIDGE,width=5)
    e2.place(x=270,y=50)

    l3=Label(f1,text='Idli Vada',bg='red',fg='yellow',font=('Algerian',18))
    l3.place(x=5,y=90)

    a3=StringVar()

    e3=Entry(f1,textvariable=a3,bg='#aeebfc',bd=5,fg='#2b00ff',font=('Algerian',18),relief=RIDGE,width=5)
    e3.place(x=270,y=90)

    l4=Label(f1,text='Hakka Noodles',bg='red',fg='yellow',font=('Algerian',18))
    l4.place(x=5,y=130)

    a4=StringVar()

    e4=Entry(f1,textvariable=a4,bg='#aeebfc',bd=5,fg='#2b00ff',font=('Algerian',18),relief=RIDGE,width=5)
    e4.place(x=270,y=130)

    l5=Label(f1,text='Tea',bg='red',fg='yellow',font=('Algerian',18))
    l5.place(x=5,y=170)

    a5=StringVar()

    e5=Entry(f1,textvariable=a5,bg='#aeebfc',bd=5,fg='#2b00ff',font=('Algerian',18),relief=RIDGE,width=5)
    e5.place(x=270,y=170)

    l6=Label(f1,text='Coffee',bg='red',fg='yellow',font=('Algerian',18))
    l6.place(x=5,y=210)

    a6=StringVar()

    e6=Entry(f1,textvariable=a6,bg='#aeebfc',bd=5,fg='#2b00ff',font=('Algerian',18),relief=RIDGE,width=5)
    e6.place(x=270,y=210)

    l7=Label(f1,text='Juice',bg='red',fg='yellow',font=('Algerian',18))
    l7.place(x=5,y=250)

    a7=StringVar()

    e7=Entry(f1,textvariable=a7,bg='#aeebfc',bd=5,fg='#2b00ff',font=('Algerian',18),relief=RIDGE,width=5)
    e7.place(x=270,y=250)

    l8=Label(f1,text='Pancakes',bg='red',fg='yellow',font=('Algerian',18))
    l8.place(x=5,y=290)

    a8=StringVar()

    e8=Entry(f1,textvariable=a8,bg='#aeebfc',bd=5,fg='#2b00ff',font=('Algerian',18),relief=RIDGE,width=5)
    e8.place(x=270,y=290)

    l9=Label(f1,text='omelette',bg='red',fg='yellow',font=('Algerian',18))
    l9.place(x=5,y=330)

    a9=StringVar()

    e9=Entry(f1,textvariable=a9,bg='#aeebfc',bd=5,fg='#2b00ff',font=('Algerian',18),relief=RIDGE,width=5)
    e9.place(x=270,y=330)

    b1=Button(f1,text='Reset',width=8,bg='#bb8bd6',fg='#91202d',command=f1reset,font=('Algerian',18),relief=RIDGE)
    b1.place(x=10,y=450)

    b2=Button(f1,text='Total',width=8,bg='#bb8bd6',command=f1total,fg='#91202d',font=('Algerian',18),relief=RIDGE)
    b2.place(x=200,y=450)



    #third frame

    f2=Frame(t3,bg='silver',bd=10,width=420,height=550,relief=RIDGE)
    f2.place(x=845,y=100)

    l1=Label(f2,text='BILL',bg='gold',fg='blue',bd=10,font=('Algerian',20))
    l1.place(x=165,y=10)




    t3.mainloop()




#login page---------------------------------------------------------------------------------------------

def login_main():
    user = username.get()
    pas = password.get()

    if user == '' and pas == '':
        win = Toplevel(winn)
        win.geometry('1920x1080')
        win.title('𝓗𝓞𝓣𝓔𝓛 𝓜𝓐𝓝𝓐𝓖𝓔𝓜𝓔𝓝𝓣 𝓢𝓨𝓢𝓣𝓔𝓜')

        img_1 = Image.open('D:\\python\\hotel management\\images\\hotel_2.jpg')
        img_1 = img_1.resize((1920, 180), Image.Resampling.LANCZOS)
        img1 = ImageTk.PhotoImage(img_1)

        l1 = Label(win, image=img1)
        l1.place(x=0, y=0)

        l2 = Label(win, text='𝓦𝓔𝓛𝓒𝓞𝓜𝓔 𝓣𝓞 𝓗𝓞𝓣𝓔𝓛 𝓜𝓐𝓝𝓐𝓖𝓔𝓜𝓔𝓝𝓣 𝓢𝓨𝓢𝓣𝓔𝓜', fg='gold', bg='black',
                   font=('Franklin Gothic Heavy', 28))
        l2.place(x=0, y=180, width=1720, height=30)

        img_2 = Image.open('D:\\python\\hotel management\\images\\hotel_3.jpg')
        img_2 = img_2.resize((1020, 445), Image.Resampling.LANCZOS)
        img2 = ImageTk.PhotoImage(img_2)

        l3 = Label(win, image=img2)
        l3.place(x=250, y=242)

        l4 = Label(win, text='MENU--->', fg='gold', bg='black', font=('Algerian', 20))
        l4.place(x=0, y=212, width=250, height=35)

        b1 = Button(win, text='COSTUMER', command=cost_butt, fg='gold', bg='black', font=('Algerian', 15))
        b1.place(x=250, y=212, width=200, height=30)

        b2 = Button(win, text='MENU', fg='gold', command=menu, bg='black', font=('Algerian', 15))
        b2.place(x=455, y=212, width=200, height=30)

        b4 = Button(win, text='BILLING', fg='gold', command=bill, bg='black', font=('Algerian', 15))
        b4.place(x=660, y=212, width=200, height=30)

        b3 = Button(win, text='TABLE NO', fg='gold', bg='black', font=('Algerian', 15))
        b3.place(x=866, y=212, width=200, height=30)

        b5 = Button(win, text='LOGOUT', fg='gold', bg='black', command=winn.destroy, font=('Algerian', 15))
        b5.place(x=1070, y=212, width=200, height=30)

        img_3 = Image.open('D:\\python\\hotel management\\images\\dining_1.jpeg')
        img_3 = img_3.resize((248, 140), Image.Resampling.LANCZOS)
        img3 = ImageTk.PhotoImage(img_3)

        l5 = Label(win, image=img3)
        l5.place(x=0, y=380)

        img_4 = Image.open('D:\\python\\hotel management\\images\\food_1.jpg')
        img_4 = img_4.resize((248, 140), Image.Resampling.LANCZOS)
        img4 = ImageTk.PhotoImage(img_4)

        l6 = Label(win, image=img4)
        l6.place(x=0, y=520)

        img_5 = Image.open('D:\\python\\hotel management\\images\\food_2.jpg')
        img_5 = img_5.resize((248, 130), Image.Resampling.LANCZOS)
        img5 = ImageTk.PhotoImage(img_5)

        l5 = Label(win, image=img5)
        l5.place(x=0, y=250)

        win.mainloop()


def reset():
    e1.delete(0, END)
    e2.delete(0, END)


winn = Tk()
winn.geometry('1920x1080')
winn.title('LOGIN SYSTEM')
'''
img_1 = Image.open('D:\\python\\Project Hotel Management System\\login_1.jpg')
img_1 = img_1.resize((1920, 1080), Image.Resampling.LANCZOS)
img1 = ImageTk.PhotoImage(img_1)

l1 = Label(winn, image=img1)
l1.place(x=0, y=0)
'''
l2 = Label(winn, text='LOGIN SYSTEM', fg='gold', bd=3, bg='#d2fae9', font=('Franklin Gothic Heavy', 30))
l2.place(x=450, y=180, width=402, height=30)

frame_1 = LabelFrame(winn, text='PLEASE FILL THE DETAILS', bg='#cde3cc', bd=20, relief=RIDGE, font=('Algerian', 13))
frame_1.place(x=330, y=210, width=600, height=300)

l3 = Label(frame_1, text='USERNAME', fg='#5d8581', font=('Algerian', 20))
l3.place(x=10, y=30)

username = StringVar()

e1 = Entry(frame_1, textvariable=username, bg='#7a6ee6', bd=2, fg='#850b27', font=('Algerian', 20), width=20)
e1.place(x=200, y=30)

l4 = Label(frame_1, text='PASSWORD', fg='#5d8581', font=('Algerian', 20))
l4.place(x=10, y=90)

password = StringVar()

e2 = Entry(frame_1, textvariable=password, bg='#7a6ee6', bd=2, fg='#850b27', font=('Algerian', 20), width=20)
e2.place(x=200, y=90)

b1 = Button(frame_1, text='LOGIN', width=8, bg='#bb8bd6', fg='#91202d', command=login_main, font=('Algerian', 13))
b1.place(x=20, y=200)

b2 = Button(frame_1, text='RESET', width=8, bg='#bb8bd6', fg='#91202d', command=reset, font=('Algerian', 13))
b2.place(x=120, y=200)

b3 = Button(frame_1, text='EXIT', width=8, bg='#bb8bd6', fg='#91202d', command=winn.destroy, font=('Algerian', 13))
b3.place(x=220, y=200)

winn.mainloop()


